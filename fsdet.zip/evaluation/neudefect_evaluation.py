"""
作者：李鹏浩
学校：NWPU
"""
# -*- coding: utf-8 -*-

import logging
import os
import tempfile
import xml.etree.ElementTree as ET
from collections import OrderedDict, defaultdict
from functools import lru_cache

import pdb
import numpy as np
import torch
from detectron2.data import MetadataCatalog
from detectron2.utils import comm
from detectron2.utils.logger import create_small_table

from fsdet.evaluation.evaluator import DatasetEvaluator


class NEUDefectEvaluator(DatasetEvaluator):

    # 初始化一个用于处理数据集的类
    def __init__(self, dataset_name):
        self._dataset_name = dataset_name
        meta = MetadataCatalog.get(dataset_name)
        self._anno_file_template = os.path.join(
            meta.dirname, "ANNOTATIONS", "{}.xml"
        )
        self._image_set_path = os.path.join(
            meta.dirname, "ImageSets", "Main", meta.split + ".txt"
        )
        self._class_names = meta.thing_classes
        # add this two terms for calculating the mAP of different subset
        self._base_classes = meta.base_classes
        self._novel_classes = meta.novel_classes
        # pdb.set_trace()
        self._is_2007 = meta.year == 0
        self._cpu_device = torch.device("cpu")
        self._logger = logging.getLogger(__name__)

    # 清空当前检测器的预测结果，以便进行下一轮预测
    def reset(self):
        self._predictions = defaultdict(
            list
        )  # class name -> list of prediction strings

    # 将模型输出的预测结果进行处理，并存储到self._predictions中，以便后续进行后处理或输出
    def process(self, inputs, outputs):
        for input, output in zip(inputs, outputs):
            image_id = input["image_id"]
            instances = output["instances"].to(self._cpu_device)
            boxes = instances.pred_boxes.tensor.numpy()
            scores = instances.scores.tolist()
            classes = instances.pred_classes.tolist()
            for box, score, cls in zip(boxes, scores, classes):
                xmin, ymin, xmax, ymax = box
                xmin += 1
                ymin += 1
                self._predictions[cls].append(
                    f"{image_id} {score:.3f} {xmin:.1f} {ymin:.1f} {xmax:.1f} {ymax:.1f}"
                )

    def evaluate(self):
        """
        Returns:
            dict: has a key "segm", whose value is a dict of "AP", "AP50", and "AP75".
        """
        # 将所有进程中的预测结果收集到主进程中
        all_predictions = comm.gather(self._predictions, dst=0)
        if not comm.is_main_process():
            return
        # 用于存储预测结果
        predictions = defaultdict(list)
        # 迭代获得每个进程的预测结果，并将每个类别的预测结果添加到predictions字典中对应类别ID的列表中
        # 最后，删除all_predictions列表，以释放内存
        for predictions_per_rank in all_predictions:
            for clsid, lines in predictions_per_rank.items():
                predictions[clsid].extend(lines)
        del all_predictions

        # 打印信息，说明正在对哪个数据集进行评估
        self._logger.info(
            "Evaluating {} using {} metric. "
            "Note that results do not use the official Matlab API.".format(
                self._dataset_name, 2007 if self._is_2007 else 0
            )
        )


        with tempfile.TemporaryDirectory(prefix="neudefect_eval_") as dirname:
            # 创建一个结果文件路径的模板
            res_file_template = os.path.join(dirname, "{}.txt")

            # aps用于存储所有类别的AP结果
            aps = defaultdict(list)  # iou -> ap per class
            # aps_base用于存储基类的AP结果
            aps_base = defaultdict(list)
            # aps_novel用于存储新类别的AP结果
            aps_novel = defaultdict(list)
            # exist_base和exist_novel是布尔变量，表示是否存在基准类别和新类别，初始值都为False
            exist_base, exist_novel = False, False

            # 遍历所有类别名称
            for cls_id, cls_name in enumerate(self._class_names):
                # 获取类别ID对应的预测结果列表，如果未找到对应的预测结果列表，则使用一个空列表作为默认值
                lines = predictions.get(cls_id, [""])

                # 将预测结果按照类别名称写入到不同的文件中，每个文件包含对应类别的预测结果，每行一个预测结果
                with open(res_file_template.format(cls_name), "w") as f:
                    f.write("\n".join(lines))

                # 在给定阈值范围内，计算目标检测每个类别的平均精度，
                # 并将结果存储到字典aps、aps_base和aps_novel中
                for thresh in range(50, 100, 5):
                    rec, prec, ap = neudefect_eval(
                        res_file_template,
                        self._anno_file_template,
                        self._image_set_path,
                        cls_name,
                        ovthresh=thresh / 100.0,
                        use_07_metric=self._is_2007,
                    )
                    aps[thresh].append(ap * 100)

                    if (
                        self._base_classes is not None
                        and cls_name in self._base_classes
                    ):
                        aps_base[thresh].append(ap * 100)
                        exist_base = True

                    if (
                        self._novel_classes is not None
                        and cls_name in self._novel_classes
                    ):
                        aps_novel[thresh].append(ap * 100)
                        exist_novel = True

        # 计算目标检测的平均精度和不同阈值下的平均精度，并将结果存储到有序字典ret中
        ret = OrderedDict()
        mAP = {iou: np.mean(x) for iou, x in aps.items()}
        ret["bbox"] = {
            "AP": np.mean(list(mAP.values())),
            "AP50": mAP[50],
            "AP75": mAP[75],
        }

        # 用于添加基准类别和新增类别的平均精度评估结果
        # adding evaluation of the base and novel classes
        if exist_base:
            mAP_base = {iou: np.mean(x) for iou, x in aps_base.items()}
            ret["bbox"].update(
                {
                    "bAP": np.mean(list(mAP_base.values())),
                    "bAP50": mAP_base[50],
                    "bAP75": mAP_base[75],
                }
            )

        # 用于计算新增类别的平均精度评估结果，并将其添加到目标检测的平均精度结果中
        if exist_novel:
            mAP_novel = {iou: np.mean(x) for iou, x in aps_novel.items()}
            ret["bbox"].update(
                {
                    "nAP": np.mean(list(mAP_novel.values())),
                    "nAP50": mAP_novel[50],
                    "nAP75": mAP_novel[75],
                }
            )

        # write per class AP to logger
        # 将每个类别的平均精度AP记录到日志中，并返回整体的平均精度结果
        per_class_res = {
            self._class_names[idx]: ap for idx, ap in enumerate(aps[50])
        }

        self._logger.info(
            "Evaluate per-class mAP50:\n" + create_small_table(per_class_res)
        )
        self._logger.info(
            "Evaluate overall bbox:\n" + create_small_table(ret["bbox"])
        )
        return ret


@lru_cache(maxsize=None)

# 用于解析标注文件
def parse_rec(filename):
    tree = ET.parse(filename)
    objects = []
    for obj in tree.findall("object"):
        obj_struct = {}
        obj_struct["name"] = obj.find("name").text
        obj_struct["pose"] = obj.find("pose").text
        obj_struct["truncated"] = int(obj.find("truncated").text)
        obj_struct["difficult"] = int(obj.find("difficult").text)
        bbox = obj.find("bndbox")
        obj_struct["bbox"] = [
            int(bbox.find("xmin").text),
            int(bbox.find("ymin").text),
            int(bbox.find("xmax").text),
            int(bbox.find("ymax").text),
        ]
        objects.append(obj_struct)

    return objects


def neudefect_ap(rec, prec, use_07_metric=False):
    if use_07_metric:
        # 11 point metric
        ap = 0.0
        for t in np.arange(0.0, 1.1, 0.1):
            if np.sum(rec >= t) == 0:
                p = 0
            else:
                p = np.max(prec[rec >= t])
            ap = ap + p / 11.0
    else:
        # correct AP calculation
        # first append sentinel values at the end
        mrec = np.concatenate(([0.0], rec, [1.0]))
        mpre = np.concatenate(([0.0], prec, [0.0]))

        # compute the precision envelope
        for i in range(mpre.size - 1, 0, -1):
            mpre[i - 1] = np.maximum(mpre[i - 1], mpre[i])

        # to calculate area under PR curve, look for points
        # where X axis (recall) changes value
        i = np.where(mrec[1:] != mrec[:-1])[0]

        # and sum (\Delta recall) * prec
        ap = np.sum((mrec[i + 1] - mrec[i]) * mpre[i + 1])
    return ap


def neudefect_eval(
    detpath,
    annopath,
    imagesetfile,
    classname,
    ovthresh=0.5,
    use_07_metric=True,
):

    # 打开图像集文件，并读取其中的所有行。
    with open(imagesetfile, "r") as f:
        lines = f.readlines()
    # 去除每行的换行符，并将结果存储在列表imagenames中
    imagenames = [x.strip() for x in lines]
    # pdb.set_trace()
    # load annots
    # 循环遍历imagenames列表中的每个图像名称，并构建相应的标注文件路径。
    # 然后对每个标注文件进行解析。
    # 解析结果被存储在字典中，其中键是图像名称，值是解析得到的标注信息
    recs = {}
    for imagename in imagenames:
        recs[imagename] = parse_rec(annopath.format(imagename))

    # extract gt objects for this class
    # 从所有图像的标注信息中提取classname类别的目标物体，并将其存储在class_recs字典中
    class_recs = {}
    npos = 0
    for imagename in imagenames:
        R = [obj for obj in recs[imagename] if obj["name"] == classname]
        bbox = np.array([x["bbox"] for x in R])
        difficult = np.array([x["difficult"] for x in R]).astype(bool)
        det = [False] * len(R)
        npos = npos + sum(~difficult)
        class_recs[imagename] = {
            "bbox": bbox,
            "difficult": difficult,
            "det": det,
        }

    # 读取目标检测结果文件并解析其中的信息
    # read dets
    detfile = detpath.format(classname)
    with open(detfile, "r") as f:
        lines = f.readlines()

    splitlines = [x.strip().split(" ") for x in lines]
    image_ids = [x[0] for x in splitlines]
    confidence = np.array([float(x[1]) for x in splitlines])
    BB = np.array([[float(z) for z in x[2:]] for x in splitlines]).reshape(
        -1, 4
    )

    # 根据目标检测结果的置信度对结果进行排序，并相应地调整边界框和图像ID的顺序
    # sort by confidence
    sorted_ind = np.argsort(-confidence)
    BB = BB[sorted_ind, :]
    image_ids = [image_ids[x] for x in sorted_ind]

    # 使用与真实物体边界框的重叠计算来确定每个边界框是否为真正例或假正例
    # go down dets and mark TPs and FPs
    nd = len(image_ids)
    tp = np.zeros(nd)
    fp = np.zeros(nd)
    for d in range(nd):
        R = class_recs[image_ids[d]]
        bb = BB[d, :].astype(float)
        ovmax = -np.inf
        BBGT = R["bbox"].astype(float)

        if BBGT.size > 0:
            # compute overlaps
            # intersection
            ixmin = np.maximum(BBGT[:, 0], bb[0])
            iymin = np.maximum(BBGT[:, 1], bb[1])
            ixmax = np.minimum(BBGT[:, 2], bb[2])
            iymax = np.minimum(BBGT[:, 3], bb[3])
            iw = np.maximum(ixmax - ixmin + 1.0, 0.0)
            ih = np.maximum(iymax - iymin + 1.0, 0.0)
            inters = iw * ih

            # union
            uni = (
                (bb[2] - bb[0] + 1.0) * (bb[3] - bb[1] + 1.0)
                + (BBGT[:, 2] - BBGT[:, 0] + 1.0)
                * (BBGT[:, 3] - BBGT[:, 1] + 1.0)
                - inters
            )

            overlaps = inters / uni
            ovmax = np.max(overlaps)
            jmax = np.argmax(overlaps)

        if ovmax > ovthresh:
            if not R["difficult"][jmax]:
                if not R["det"][jmax]:
                    tp[d] = 1.0
                    R["det"][jmax] = 1
                else:
                    fp[d] = 1.0
        else:
            fp[d] = 1.0

    # 用于计算目标检测的精确率-召回率曲线以及平均精度
    # compute precision recall
    fp = np.cumsum(fp)
    tp = np.cumsum(tp)
    rec = tp / float(npos)
    # avoid divide by zero in case the first detection matches a difficult
    # ground truth
    prec = tp / np.maximum(tp + fp, np.finfo(np.float64).eps)
    ap = neudefect_ap(rec, prec, use_07_metric)

    # 返回召回率数组rec、精确率数组prec和平均精度ap
    return rec, prec, ap
