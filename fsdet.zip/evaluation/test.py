imagesetfile = "../../datasets/NEUDEFECT/ImageSets/Main/test.txt"
with open(imagesetfile,"r") as f:
    lines = f.readlines()
    print(lines)