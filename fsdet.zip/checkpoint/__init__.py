from detectron2.checkpoint import DetectionCheckpointer

from . import catalog as _UNUSED  # register the handler

__all__ = ["DetectionCheckpointer"]
