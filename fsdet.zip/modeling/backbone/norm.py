import torch.nn as nn

def build_BNnorm_layer(num_features, postfix=''):
    """Build normalization layer.

    Args:
        cfg (dict): The norm layer config, which should contain:

            - type (str): Layer type.
            - layer args: Args needed to instantiate a norm layer.
            - requires_grad (bool, optional): Whether stop gradient updates.
        num_features (int): Number of input channels.
        postfix (int | str): The postfix to be appended into norm abbreviation
            to create named layer.

    Returns:
        (str, nn.Module): The first element is the layer name consisting of
            abbreviation and postfix, e.g., bn1, gn. The second element is the
            created norm layer.
    """

    norm_layer = nn.BatchNorm2d
    abbr = 'bn'

    layer_type = 'BN'

    assert isinstance(postfix, (int, str))
    name = abbr + str(postfix)

    requires_grad = True
    if layer_type != 'GN':
        layer = norm_layer(num_features)

    for param in layer.parameters():
        param.requires_grad = requires_grad

    return name, layer