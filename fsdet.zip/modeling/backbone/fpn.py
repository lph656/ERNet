# Copyright (c) Facebook, Inc. and its affiliates.
import math
import fvcore.nn.weight_init as weight_init
import torch
import torch.nn.functional as F
from torch import nn

from detectron2.layers import Conv2d, ShapeSpec, get_norm

from fsdet.modeling.backbone import Backbone
from fsdet.modeling.backbone.build import BACKBONE_REGISTRY
from fsdet.modeling.backbone.resnet import build_resnet_backbone
from pytorch_wavelets import DWTForward
from fsdet.modeling.backbone.deformconv import DeformableConv2d

__all__ = ["build_resnet_fpn_backbone", "FPN"]


class FPN(Backbone):
    _fuse_type: torch.jit.Final[str]

    def __init__(
        self,
        bottom_up,
        in_features,
        out_channels,
        norm="",
        top_block=None,
        fuse_type="sum",
        square_pad=0,
    ):
        super(FPN, self).__init__()
        assert isinstance(bottom_up, Backbone)
        assert in_features, in_features

        input_shapes = bottom_up.output_shape()
        strides = [input_shapes[f].stride for f in in_features]
        in_channels_per_feature = [input_shapes[f].channels for f in in_features]

        _assert_strides_are_log2_contiguous(strides)
        lateral_convs = []
        output_convs = []

        use_bias = norm == ""
        for idx, in_channels in enumerate(in_channels_per_feature):
            lateral_norm = get_norm(norm, out_channels)
            output_norm = get_norm(norm, out_channels)

            lateral_conv = Conv2d(
                in_channels, out_channels, kernel_size=1, bias=use_bias, norm=lateral_norm
            )
            output_conv = Conv2d(
                out_channels,
                out_channels,
                kernel_size=3,
                stride=1,
                padding=1,
                bias=use_bias,
                norm=output_norm,
            )
            weight_init.c2_xavier_fill(lateral_conv)
            weight_init.c2_xavier_fill(output_conv)
            stage = int(math.log2(strides[idx]))
            self.add_module("fpn_lateral{}".format(stage), lateral_conv)
            self.add_module("fpn_output{}".format(stage), output_conv)

            lateral_convs.append(lateral_conv)
            output_convs.append(output_conv)

        self.attention_laterall_conv = Conv2d(4096,256,kernel_size=1,bias=use_bias,norm=get_norm(norm,256))
        self.attention_output_conv = Conv2d(256,256,kernel_size=3,stride=1,padding=1,bias=use_bias,norm=get_norm(norm,256))

        self.lateral_convs = lateral_convs[::-1]
        self.output_convs = output_convs[::-1]

        self.top_block = top_block
        self.in_features = tuple(in_features)
        self.bottom_up = bottom_up
        # Return feature names are "p<stage>", like ["p2", "p3", ..., "p6"]
        self._out_feature_strides = {"p{}".format(int(math.log2(s))): s for s in strides}
        # top block output feature maps.
        if self.top_block is not None:
            for s in range(stage, stage + self.top_block.num_levels):
                self._out_feature_strides["p{}".format(s + 1)] = 2 ** (s + 1)

        self._out_features = list(self._out_feature_strides.keys())
        self._out_feature_channels = {k: out_channels for k in self._out_features}
        self._size_divisibility = strides[-1]
        self._square_pad = square_pad
        assert fuse_type in {"avg", "sum"}
        self._fuse_type = fuse_type

    @property
    def size_divisibility(self):
        return self._size_divisibility

    @property
    def padding_constraints(self):
        return {"square_size": self._square_pad}

    def forward(self, x):
        """
        Args:
            input (dict[str->Tensor]): mapping feature map name (e.g., "res5") to
                feature map tensor for each feature level in high to low resolution order.

        Returns:
            dict[str->Tensor]:
                mapping from feature map name to FPN feature map tensor
                in high to low resolution order. Returned feature names follow the FPN
                paper convention: "p<stage>", where stage has stride = 2 ** stage e.g.,
                ["p2", "p3", ..., "p6"].
        """
        bottom_up_features = self.bottom_up(x)
        results = []

        attentation_features = self.top_block(bottom_up_features[self.in_features[-1]])
        prev_features = self.attention_laterall_conv(attentation_features)
        results.append(self.attention_output_conv(prev_features))


        features = self.in_features[-1]
        features = bottom_up_features[features]
        lateral_features = self.lateral_convs[0](features)
        lateral_shape = lateral_features.shape[2:]
        top_down_features = F.interpolate(prev_features, size=lateral_shape, mode="nearest")
        prev_features = lateral_features + top_down_features
        if self._fuse_type == "avg":
            prev_features /= 2
        results.insert(0, self.output_convs[0](prev_features))

        # Reverse feature maps into top-down order (from low to high resolution)
        for idx, (lateral_conv, output_conv) in enumerate(
            zip(self.lateral_convs, self.output_convs)
        ):
            if idx > 0:
                features = self.in_features[-idx - 1]
                features = bottom_up_features[features]
                top_down_features = F.interpolate(prev_features, scale_factor=2.0, mode="nearest")
                lateral_features = lateral_conv(features)
                prev_features = lateral_features + top_down_features
                if self._fuse_type == "avg":
                    prev_features /= 2
                results.insert(0, output_conv(prev_features))
        """
        if self.top_block is not None:
            if self.top_block.in_feature in bottom_up_features:
                top_block_in_feature = bottom_up_features[self.top_block.in_feature]
            else:
                top_block_in_feature = results[self._out_features.index(self.top_block.in_feature)]
            results.extend(self.top_block(top_block_in_feature))
        assert len(self._out_features) == len(results)
        """
        return {f: res for f, res in zip(self._out_features, results)}

    def output_shape(self):
        return {
            name: ShapeSpec(
                channels=self._out_feature_channels[name], stride=self._out_feature_strides[name]
            )
            for name in self._out_features
        }


def _assert_strides_are_log2_contiguous(strides):
    """
    Assert that each stride is 2x times its preceding stride, i.e. "contiguous in log2".
    """
    for i, stride in enumerate(strides[1:], 1):
        assert stride == 2 * strides[i - 1], "Strides {} {} are not log2 contiguous".format(
            stride, strides[i - 1]
        )

class SELayerada(nn.Module):
    def __init__(self, channel, reduction=16):
        super(SELayerada, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # self.dropput=F.dropout(p=0.5),
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.GELU(),
            nn.Dropout(p=0.5),
            # F.dropout(p=0.5),
            # nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Dropout(p=0.5),
            nn.Sigmoid()
        )
    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)

class SELayermax(nn.Module):
    def __init__(self, channel, reduction=16):
        super(SELayermax, self).__init__()
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.GELU(),
            nn.Dropout(p=0.5),
            # nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Dropout(p=0.5),
            nn.Sigmoid()
        )
    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.max_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)


class softmaxattention1(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self,channel, k=1, s=1, p=None):  # ch_in, ch_out, number, shortcut, groups, expansion

        self.num_levels = 1
        self.in_feature = "res5"

        super(softmaxattention1, self).__init__()
        # hidden channels
        #print('c1',c1/8)
        # self.cv1 = Conv(2048,256, 3, 1,1)#640*640*9
        # self.cv2 = Conv(2048,256, 5, 1,2)#640*640*6
        # self.cv1= conv3x3(1024,128, 3, 1,1)
        # self.cv2 = conv3x3(1024, 128, 3, 1, 1)
        self.se1=SELayerada(channel,reduction=16)
        self.se2 = SELayermax(channel, reduction=16)
        # self.cv1 = conv1x1(2048, 2048)  # 640*640*9
        # self.cv2 = conv3x3(2048, 2048)  # 640*640*6
        # self.cv3 = conv1x1(2048,2048,stride=1)
        # self.cv4 = conv1x1_down(4096, 4096)
        # self.cv5 =conv1x1(12288,4096)
        # self.dcn = dcn
        # if self.dcn:
        #     fallback_on_stride = dcn.pop('fallback_on_stride', False)
        self.cv1 = nn.Conv2d(2048, 2048, kernel_size=1,stride=1,padding=0,dilation=1,bias=False)
        self.cv2 = nn.Conv2d(2048, 2048, kernel_size=3, stride=1, padding=1, dilation=1, bias=False)
        self.cv3 = nn.Conv2d(2048, 2048, kernel_size=1, stride=1, padding=0, dilation=1, bias=False)
        # self.cv4 = build_conv_layer(dcn, 4096, 4096, kernel_size=1, stride=2, padding=0, dilation=1, bias=False)
        self.cv5 = nn.Conv2d(2048, 4096, kernel_size=1, stride=1, padding=0, dilation=1, bias=False)
        self.cv6 = nn.Conv2d(8192, 2048, kernel_size=1, stride=1, padding=0, dilation=1, bias=False)
        #self.cv6 = nn.Conv2d(4096, 2048, kernel_size=1, stride=1, padding=0, dilation=1, bias=False)
        self.switch = nn.Conv2d(2048, 1, kernel_size=1, stride=1, bias=True)
        self.xfm = DWTForward(J=1, wave='db1', mode='zero')
        #self.cv3 = Conv(6, 3,3, 1,1)  #640*640*3# act=FReLU(c2)
        #Conv(3, 3, 1, 1, 0)
        #self.m 6= nn.Sequential(*[Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)])
        # self.m = nn.Sequential(*[CrossConv(c_, c_, 3, 1, g, 1.0, shortcut) for _ in range(n)])

    # yichu xiaobo bianhuan
    """def forward(self, x):
        x_ = x

        # ?????????????DWT????
        y1 = self.cv1(x)  # [B, C, H, W]
        y2 = self.cv2(x)  # [B, C, H, W]
        y3 = self.cv3(x)  # [B, C, H, W]

        # Squeeze-and-Excitation??
        y1se = self.se1(y1)
        y2se = self.se2(y2)

        # Reshape??????
        y2_ = y2se.view([y2.size()[0], y2.size()[1], -1])  # [B, C, H*W]
        y1_ = y1se.view([y1.size()[0], y1.size()[1], -1])  # [B, C, H*W]
        y2_T = y2_.permute([0, 2, 1])  # [B, H*W, C]

        # ??QK????????
        c = torch.matmul(y2_T, y1_)  # [B, H*W, H*W]
        C_weight = F.softmax(c, dim=-1)  # [B, H*W, H*W]

        # ???????????
        y3_ = y3.view([x.size()[0], x.size()[1], -1])  # [B, C, H*W]
        y_last = torch.matmul(y3_, C_weight)
        y_last = torch.nn.functional.normalize(y_last)

        # ????????????????
        y_last_ = y_last.view([x.size()[0], x.size()[1], x.size()[2], x.size()[3]])  # [B, C, H, W]

        # ??????switch?????
        switch = self.switch(y_last_)

        # ???????
        kkk = self.cv6(torch.cat([x, y_last_], dim=1))  # ??????????
        kkk_ = switch * y_last_ + (1 - switch) * kkk  # ?????

        # ????
        zhao_new = self.cv5(kkk_)

        return zhao_new"""
    #yuan shi
    def forward(self, x):
        x_=x
        coeffs_yl,coeffs_yh=self.xfm(x)
        # coeffs_yl,coeffs_yh=coeffs_yl.cuda(),coeffs_yh.cuda()
        coeffs_yh,coeffs_yh1,coeffs_yh2=coeffs_yh[0][:,:,0,:,:],coeffs_yh[0][:,:,1,:,:],coeffs_yh[0][:,:,2,:,:]
        # pywt.dwt2(x.cpu().numpy(), 'db1')
        kkk = torch.cat([coeffs_yl, coeffs_yh, coeffs_yh1,
                         coeffs_yh2], dim=1)

        #print('x1',x.shape)
        y1=self.cv1(x)  ##[B,C,H,W]  C
        #print('y1', y1.shape)
        y2=self.cv2(x)  ##  B
        y1se=self.se1(y1)
        y2se=self.se2(y2)
        y3=self.cv3(x)
        #print('y2', y2.shape)##[B,C,H,W]
        # x_= x.view([x.size()[0], x.size()[1], -1])#[B,C,H*w]
        #print('x_', x_.shape)  ##[B,C,H,W]

        y2_=y2se.view([y2.size()[0],y2.size()[1],-1]) #[B,C,H*w] 0 1 2
        #print('y2_', y2_.shape)  ##[B,C,H*w] 0 1 2
        y1_ = y1se.view([y1.size()[0], y1.size()[1], -1])  # [B,C,H*w] 0 1 2
        #print('y1_ ', y1_ .shape)  ##[B,C,H*w] 0 1 2

        y2_T = y2_.permute([0,2,1])  # [B,H*w,C]  0 2 1  D   ###K
        #print('y2_T ', y2_T.shape)# [B,H*w,C]
        #c=y1_*y2_T  #[B,C,H*w]  * [B,H*w,C]
        c=torch.matmul(y2_T,y1_ ) #[B,H*w,H*w]  ###QK
        #print('c ', c.shape)  # [B,H*w,H*w]
        C_weight=F.softmax(c,dim=-1)   ##[B,H*w,H*w]  E
        #print('C_weight', C_weight.shape)  # [B,H*w,H*w]
        #y=C*x
        y3_=y3.view([x.size()[0], x.size()[1], -1])
        y_last =torch.matmul(y3_,C_weight)
        y_last = torch.nn.functional.normalize(y_last)
        # y_last = torch.matmul(x_,C_weight) #[B,C,H*w] *[B,H*w,H*w]  F-  ###yuanshi
        y_last_ = y_last.view([x.size()[0], x.size()[1], x.size()[2], x.size()[3]])  # [B,C,H*w] 0 1 2
        # y_last_ = torch.nn.functional.normalize(y_last_)
        # zhao=torch.add(y_last_, x)
        # zhao=torch.cat((y_last_,x),dim=1)
        zhao,_=self.xfm(y_last_)
        # avg_x = F.adaptive_avg_pool2d(x, output_size=1)
        # avg_x = self.pre_context(avg_x)
        # avg_x = avg_x.expand_as(x)
        # x = x + avg_x

        avg_x = F.pad(x_ ,pad=(2, 2, 2, 2), mode='reflect')
        avg_x = F.avg_pool2d(avg_x, kernel_size=5, stride=1, padding=0)
        coeffs_yl_,_ = self.xfm(avg_x)
        switch =  self.switch(coeffs_yl_)

        kkk =self.cv6(kkk)
        kkk_ = switch * zhao + (1 - switch) * kkk

        # kkk_=torch.cat((zhao,kkk),dim=1) #尝试下add
        zhao_new = self.cv5(kkk_)
        # y_last=y_last.permute([0,1,3,2])
        # y_last_.permute(0,1,3,2).contiguous()
        # zhao = torch.matmul(y_last[::-1], x)  ##y_last [B,C,H,w]   x[B,C,H,W]
        # print('y1', y1.shape)
        # y2=self.cv2(y1)

        #print('y_last_', y_last_.shape)
        return zhao_new
    """
    #yichu y1
    def forward(self, x):
        x_ = x
        coeffs_yl, coeffs_yh = self.xfm(x)

        # ????????
        assert torch.isfinite(coeffs_yl).all(), "coeffs_yl contains NaN/Inf"
        assert torch.isfinite(coeffs_yh[0]).all(), "coeffs_yh contains NaN/Inf"

        coeffs_yh, coeffs_yh1, coeffs_yh2 = coeffs_yh[0][:, :, 0, :, :], coeffs_yh[0][:, :, 1, :, :], coeffs_yh[0][:, :,
                                                                                                      2, :, :]
        kkk = torch.cat([coeffs_yl, coeffs_yh, coeffs_yh1, coeffs_yh2], dim=1)

        y2 = self.cv2(x)
        y2se = self.se2(y2)
        y3 = self.cv3(x)

        y2_ = y2se.view([y2.size()[0], y2.size()[1], -1])
        y2_T = y2_.permute([0, 2, 1])
        y3_ = y3.view([x.size()[0], x.size()[1], -1])

        # ??????
        #print(f"y2_T shape: {y2_T.shape}, y3_ shape: {y3_.shape}")

        # ????? softmax
        c = torch.matmul(y2_T, y2_)
        c = c - c.max(dim=-1, keepdim=True)[0]  # ?????
        C_weight = F.softmax(c, dim=-1)

        y_last = torch.matmul(y3_, C_weight)
        y_last_ = y_last.view([x.size()[0], x.size()[1], x.size()[2], x.size()[3]])

        zhao, _ = self.xfm(y_last_)
        avg_x = F.pad(x_, pad=(2, 2, 2, 2), mode='reflect')
        avg_x = F.avg_pool2d(avg_x, kernel_size=5, stride=1, padding=0)
        coeffs_yl_, _ = self.xfm(avg_x)

        # ???????
        switch = self.switch(coeffs_yl_)
        switch = torch.clamp(switch, 0, 1)

        kkk = self.cv6(kkk)
        kkk_ = switch * zhao + (1 - switch) * kkk

        zhao_new = self.cv5(kkk_)
        assert torch.isfinite(zhao_new).all(), "zhao_new contains NaN/Inf"

        return zhao_new"""

    #yichu y2
    """
    def forward(self, x):
        x_ = x
        assert torch.isfinite(x).all(), "Input x contains NaN or Inf!"

        # ????
        coeffs_yl, coeffs_yh = self.xfm(x)
        assert torch.isfinite(coeffs_yl).all(), "coeffs_yl contains NaN or Inf!"
        assert torch.isfinite(coeffs_yh[0]).all(), "coeffs_yh contains NaN or Inf!"

        coeffs_yh, coeffs_yh1, coeffs_yh2 = coeffs_yh[0][:, :, 0, :, :], coeffs_yh[0][:, :, 1, :, :], coeffs_yh[0][:, :,
                                                                                                      2, :, :]
        kkk = torch.cat([coeffs_yl, coeffs_yh, coeffs_yh1, coeffs_yh2], dim=1)

        y1 = self.cv1(x)
        y1se = self.se1(y1)
        y3 = self.cv3(x)

        y1_ = y1se.view([y1.size()[0], y1.size()[1], -1])
        y1_T = y1_.permute([0, 2, 1])
        y3_ = y3.view([x.size()[0], x.size()[1], -1])

        # ??? softmax
        c = torch.matmul(y1_T, y1_)
        c = c - c.max(dim=-1, keepdim=True)[0]  # ?????
        C_weight = F.softmax(c, dim=-1)
        y_last = torch.matmul(y3_, C_weight)
        y_last_ = y_last.view([x.size()[0], x.size()[1], x.size()[2], x.size()[3]])

        zhao, _ = self.xfm(y_last_)
        avg_x = F.pad(x_, pad=(2, 2, 2, 2), mode='reflect')
        avg_x = F.avg_pool2d(avg_x, kernel_size=5, stride=1, padding=0)
        coeffs_yl_, _ = self.xfm(avg_x)
        switch = self.switch(coeffs_yl_)

        # ????????
        switch = torch.clamp(switch, 0, 1)

        kkk = self.cv6(kkk)
        kkk_ = switch * zhao + (1 - switch) * kkk
        zhao_new = self.cv5(kkk_)

        assert torch.isfinite(zhao_new).all(), "zhao_new contains NaN or Inf!"
        return zhao_new"""

    """
    #yichu y3
    def forward(self, x):
        x_ = x
        coeffs_yl, coeffs_yh = self.xfm(x)
        coeffs_yh, coeffs_yh1, coeffs_yh2 = coeffs_yh[0][:, :, 0, :, :], coeffs_yh[0][:, :, 1, :, :], coeffs_yh[0][:, :,
                                                                                                      2, :, :]
        kkk = torch.cat([coeffs_yl, coeffs_yh, coeffs_yh1, coeffs_yh2], dim=1)

        y1 = self.cv1(x)
        y2 = self.cv2(x)
        y1se = self.se1(y1)
        y2se = self.se2(y2)

        y1_ = y1se.view([y1.size()[0], y1.size()[1], -1])
        y2_ = y2se.view([y2.size()[0], y2.size()[1], -1])
        y2_T = y2_.permute([0, 2, 1])

        # ?? Softmax ??
        c = torch.matmul(y2_T, y1_)
        c = c - c.max(dim=-1, keepdim=True).values  # ??????
        C_weight = F.softmax(c, dim=-1)

        y_last = torch.matmul(y1_, C_weight)
        y_last_ = y_last.view([x.size()[0], x.size()[1], x.size()[2], x.size()[3]])

        zhao, _ = self.xfm(y_last_)
        avg_x = F.pad(x_, pad=(2, 2, 2, 2), mode='reflect')
        avg_x = F.avg_pool2d(avg_x, kernel_size=5, stride=1, padding=0)

        coeffs_yl_, _ = self.xfm(avg_x)
        switch = self.switch(coeffs_yl_)

        kkk = self.cv6(kkk)
        kkk_ = switch * zhao + (1 - switch) * kkk
        zhao_new = self.cv5(kkk_)

        # ?????????
        assert torch.isfinite(zhao_new).all(), "NaN or Inf detected in zhao_new"

        return zhao_new"""


class LastLevelMaxPool(nn.Module):
    """
    This module is used in the original FPN to generate a downsampled
    P6 feature from P5.
    """

    def __init__(self):
        super().__init__()
        self.num_levels = 1
        self.in_feature = "res5"

    def forward(self, x):
        return [F.max_pool2d(x, kernel_size=1, stride=2, padding=0)]


@BACKBONE_REGISTRY.register()
def build_resnet_fpn_backbone(cfg, input_shape: ShapeSpec):
#def build_resnet_fpn_attention_xiaobo_backbone(cfg, input_shape: ShapeSpec):
    """
    Args:
        cfg: a detectron2 CfgNode

    Returns:
        backbone (Backbone): backbone module, must be a subclass of :class:`Backbone`.
    """
    bottom_up = build_resnet_backbone(cfg, input_shape)
    in_features = cfg.MODEL.FPN.IN_FEATURES
    out_channels = cfg.MODEL.FPN.OUT_CHANNELS
    backbone = FPN(
        bottom_up=bottom_up,
        in_features=in_features,
        out_channels=out_channels,
        norm=cfg.MODEL.FPN.NORM,
        top_block=softmaxattention1(channel=2048),
        fuse_type=cfg.MODEL.FPN.FUSE_TYPE,
    )
    return backbone