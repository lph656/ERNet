import fsdet.data.builtin as _UNUSED  # register datasets

from .defaults import (
    DefaultPredictor,
    DefaultTrainer,
    default_argument_parser,
    default_setup,
)
from .hooks import *
