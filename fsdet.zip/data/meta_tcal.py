"""
作者：李鹏浩
学校：NWPU
"""
import os
import xml.etree.ElementTree as ET

import numpy as np
from detectron2.data import DatasetCatalog, MetadataCatalog
from detectron2.structures import BoxMode
from fsdet.utils.file_io import PathManager

__all__ = ["register_meta_tcal"]

TCAL_NOVEL = {
    1:["1","3","4","8","9"]
}

def load_filtered_tcal_instances(
    name: str, dirname: str, split: str, classnames: str
):
    is_shots = "shot" in name
    is_joint = TCAL_NOVEL[int(name.split('allbase')[-1])] if 'allbase' in name else []

    if 'allnovel' in name:
        include_classnames = TCAL_NOVEL[int(name.split('allnovel')[-1][0])]
        # 使用格式化字符输出新类别名称列表的长度和内容
        print('Logging names for {} novel classes: '.format(len(include_classnames)), include_classnames)
    else:
        include_classnames = classnames

    if is_shots:
        fileids = {}
        dir = os.path.abspath('../datasets')
        #import sys
        #print(sys.path)
        split_dir = os.path.join(dir, "tcalsplit")
        shot = name.split("_")[-1].split("shot")[0]
        for cls in include_classnames:
            with PathManager.open(
                    os.path.join(
                        split_dir, "box_{}shot_{}_train.txt".format(shot, cls)
                    )
            ) as f:
                fileids_ =np.loadtxt(f,dtype=str).tolist()
                if isinstance(fileids_,str):
                    fileids_ = [fileids_]
                fileids_ = [
                    fid.split("/")[-1].split(".jpg")[0] for fid in fileids_
                ]
                fileids[cls] = fileids_
    else:
        dirname = "../datasets/TCAL"
        with PathManager.open(
                os.path.join(dirname, "ImageSets", "Main" ,split+".txt")
        ) as f:
            fileids = np.loadtxt(f, dtype=str)

    dicts = []
    if is_shots:
        for cls, fileids_ in fileids.items():
            dicts_ = []
            for fileid in fileids_:
                # 路径修改3
                dirname = os.path.join("../datasets", "TCAL")
                # 构建图片注释文件的路径
                anno_file = os.path.join(
                    dirname, "ANNOTATIONS", fileid + ".xml"
                )
                # 构建图片文件的路径
                jpeg_file = os.path.join(
                    dirname, "IMAGES", fileid + ".jpg"
                )
                # 解析注释文件，得到一个XML树
                tree = ET.parse(anno_file)

                # 遍历XML树中所有的对象元素
                for obj in tree.findall("object"):
                    # 创建一个数据字典r，包含图片文件名、图片ID、高度和宽度信息
                    r = {
                        "file_name": jpeg_file,
                        "image_id": fileid,
                        "height": int(tree.findall("./size/height")[0].text),
                        "width": int(tree.findall("./size/width")[0].text),
                    }
                    # 从对象中读取边界
                    cls_ = obj.find("name").text
                    if cls != cls_:
                        continue
                    bbox = obj.find("bndbox")
                    bbox = [
                        float(bbox.find(x).text)
                        for x in ["xmin", "ymin", "xmax", "ymax"]
                    ]
                    bbox[0] -= 1.0
                    bbox[1] -= 1.0

                    instances = [
                        {
                            "category_id": classnames.index(cls),
                            "bbox": bbox,
                            "bbox_mode": BoxMode.XYXY_ABS,
                        }
                    ]
                    r["annotations"] = instances
                    dicts_.append(r)
            if len(dicts_) > int(shot):
                # 如果当前类别的数据字典列表dicts_的长度大于设定的shot变量值，
                # 则随机选择指定数量的数据字典，结果赋值给dicts_，且不允许重复选择
                dicts_ = np.random.choice(dicts_, int(shot), replace=False)
            # 将当前类别的数据字典dicts_添加到最终的数据字典列表dicts中。
            dicts.extend(dicts_)

    else:
        for fileid in fileids:
            anno_file = os.path.join(dirname, "ANNOTATIONS", fileid + ".xml")
            jpeg_file = os.path.join(dirname, "IMAGES", fileid + ".jpg")

            tree = ET.parse(anno_file)

            r = {
                "file_name": jpeg_file,
                "image_id": fileid,
                "height": int(tree.findall("./size/height")[0].text),
                "width": int(tree.findall("./size/width")[0].text),
            }
            instances = []

            for obj in tree.findall("object"):
                cls = obj.find("name").text
                if cls not in classnames:
                    continue
                if cls in is_joint:
                    continue
                bbox = obj.find("bndbox")
                bbox = [
                    float(bbox.find(x).text)
                    for x in ["xmin","ymin","xmax","ymax"]
                ]
                bbox[0] -=1.0
                bbox[1] -=1.0
                instances.append(
                    {
                        "category_id": classnames.index(cls),
                        "bbox": bbox,
                        "bbox_mode": BoxMode.XYXY_ABS,
                    }
                )
            r["annotations"] = instances
            dicts.append(r)
    return dicts

def register_meta_tcal(
    name, metadata, dirname, split, year, keepclasses, sid
):
    if keepclasses.startswith("base_novel"):
        thing_classes = metadata["thing_classes"][sid]
    elif keepclasses.startswith("base"):
        thing_classes = metadata["base_classes"][sid]
    elif keepclasses.startswith("novel"):
        thing_classes = metadata["novel_classes"][sid]
    # 注册数据集，将数据集名称、数据加载函数和其他参数传递给该函数。
    # 数据加载函数是一个lambda函数，用于调用load_filtered_voc_instances()
    # 函数加载经过筛选的Pascal VOC实例函数。
    DatasetCatalog.register(
        name,
        lambda: load_filtered_tcal_instances(
            name, dirname, split, thing_classes
        ),
    )

    # 获取数据集的元数据对象，并使用.set()方法设置元数据的相关属性
    MetadataCatalog.get(name).set(
        thing_classes=thing_classes,
        dirname=dirname,
        year=year,
        split=split,
        base_classes=metadata["base_classes"][sid],
        novel_classes=metadata["novel_classes"][sid],
    )
