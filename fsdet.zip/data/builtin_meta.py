DEFECT_ALL_CATEGORIES = {
    1: [
        "1_chongkong",
        "2_hanfeng",
        "3_yueyawan",
        "4_shuiban",
        "5_youban",
        "6_siban",
        "7_yiwu",
        "8_yahen",
        "9_zhehen",
        "10_yaozhe",
    ],
}

DEFECT_NOVEL_CATEGORIES = {
    1: [
        "8_yahen",
        "9_zhehen",
        "10_yaozhe",
    ],
}
DEFECT_BASE_CATEGORIES = {
    1: [
        "1_chongkong",
        "2_hanfeng",
        "3_yueyawan",
        "4_shuiban",
        "5_youban",
        "6_siban",
        "7_yiwu",
    ],
}

TCAL_ALL_CATEGORIES = {
    1: ["1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "10",
    ],
}
TCAL_NOVEL_CATEGORIES = {
    1: ["1",
        "3",
        "4",
        "8",
        "9",
        ],
}

TCAL_BASE_CATEGORIES = {
    1: ["2",
        "5",
        "6",
        "7",
        "10",
    ],
}

NEUDEFECT_ALL_CATEGORIES = {
    1: ["crazing",
        "inclusion",
        "patches",
        "pitted_surface",
        "rolled-in_scale",
        "scratches",
    ],
}

NEUDEFECT_NOVEL_CATEGORIES = {
    1: [
        "crazing",
    ],
}
NEUDEFECT_BASE_CATEGORIES = {
    1: [
        "inclusion",
        "patches",
        "pitted_surface",
        "rolled-in_scale",
        "scratches",
    ],
}

def _get_defect_fewshot_instances_meta():
    ret = {
        "thing_classes": DEFECT_ALL_CATEGORIES,
        "novel_classes": DEFECT_NOVEL_CATEGORIES,
        "base_classes": DEFECT_BASE_CATEGORIES,
    }
    return ret

def _get_neudefect_fewshot_instances_meta():
    ret = {
        "thing_classes": NEUDEFECT_ALL_CATEGORIES,
        "novel_classes": NEUDEFECT_NOVEL_CATEGORIES,
        "base_classes": NEUDEFECT_BASE_CATEGORIES,
    }
    return ret

def _get_tcal_fewshot_instances_meta():
    ret = {
        "thing_classes": TCAL_ALL_CATEGORIES,
        "novel_classes": TCAL_NOVEL_CATEGORIES,
        "base_classes": TCAL_BASE_CATEGORIES,
    }
    return ret

def _get_builtin_metadata(dataset_name):
    if dataset_name == "defect_fewshot":
        return _get_defect_fewshot_instances_meta()
    elif dataset_name == "neudefect_fewshot":
        return _get_neudefect_fewshot_instances_meta()
    elif dataset_name == "tcal_fewshot":
        return _get_tcal_fewshot_instances_meta()
    raise KeyError("No built-in metadata for dataset {}".format(dataset_name))
