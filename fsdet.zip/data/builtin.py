"""
This file registers pre-defined datasets at hard-coded paths, and their metadata.
We hard-code metadata for common datasets. This will enable:
1. Consistency check when loading the datasets
2. Use models on these standard datasets directly and run demos,
   without having to download the dataset annotations
We hard-code some paths to the dataset that's assumed to
exist in "./datasets/".

Here we only register the few-shot datasets and complete COCO, PascalVOC and
LVIS have been handled by the builtin datasets in detectron2.
"""

import os
import pdb

from detectron2.data import MetadataCatalog

from .builtin_meta import _get_builtin_metadata
from .meta_defect import register_meta_defect
from .meta_neudefect import register_meta_neudefect
from .meta_tcal import register_meta_tcal

# ==== Predefined datasets and splits for COCO ==========
# ==== Predefined splits for PASCAL VOC ===========

#
def register_all_defect(root="../datasets"):
    METASPLITS = [
        ('defect_trainval_allbase1','DEFECT','trainval','base_novel_1',1),
        ('defect_trainval_allnovel1_5shot','DEFECT','all_5shot_split_1_trainval','base_novel_1',1),
        ('defect_trainval_allnovel1_10shot', 'DEFECT', 'all_10shot_split_1_trainval', 'base_novel_1', 1),
        ('defect_trainval_allnovel1_30shot', 'DEFECT', 'all_30shot_split_1_trainval', 'base_novel_1', 1),
        ('defect_test_all1','DEFECT','test','base_novel_1',1),
    ]

    for name, dirname, split, keepclasses, sid in METASPLITS:
        year = 0
        register_meta_defect(
            name,
            _get_builtin_metadata("defect_fewshot"),
            os.path.join(root, dirname),
            split,
            year,
            keepclasses,
            sid,
        )
        MetadataCatalog.get(name).evaluator_type = "defect"

def register_all_neudefect(root="../datasets"):
    METASPLITS = [
        ('neudefect_trainval_allbase1','NEUDEFECT','trainval','base_novel_1',1),
        ('neudefect_trainval_allnovel1_5shot','NEUDEFECT','all_5shot_split_1_trainval','base_novel_1',1),
        ('neudefect_trainval_allnovel1_10shot', 'NEUDEFECT', 'all_10shot_split_1_trainval', 'base_novel_1', 1),
        ('neudefect_trainval_allnovel1_30shot', 'NEUDEFECT', 'all_30shot_split_1_trainval', 'base_novel_1', 1),
        ('neudefect_test_all1','NEUDEFECT','test','base_novel_1',1),
    ]

    for name, dirname, split, keepclasses, sid in METASPLITS:
        year = 0
        register_meta_neudefect(
            name,
            _get_builtin_metadata("neudefect_fewshot"),
            os.path.join(root, dirname),
            split,
            year,
            keepclasses,
            sid,
        )
        MetadataCatalog.get(name).evaluator_type = "neudefect"

def register_all_tcal(root="../datasets"):
    METASPLITS = [
        ('tcal_trainval_allbase1','TCAL','trainval','base_novel_1',1),
        ('tcal_trainval_allnovel1_5shot','TCAL','all_5shot_split_1_trainval','base_novel_1',1),
        ('tcal_trainval_allnovel1_10shot', 'TCAL', 'all_10shot_split_1_trainval', 'base_novel_1', 1),
        ('tcal_trainval_allnovel1_30shot', 'TCAL', 'all_30shot_split_1_trainval', 'base_novel_1', 1),
        ('tcal_test_all1','TCAL','test','base_novel_1',1),
    ]

    for name, dirname, split, keepclasses, sid in METASPLITS:
        year = 0
        register_meta_tcal(
            name,
            _get_builtin_metadata("tcal_fewshot"),
            os.path.join(root, dirname),
            split,
            year,
            keepclasses,
            sid,
        )
        MetadataCatalog.get(name).evaluator_type = "tcal"
# Register them all under "./datasets"
register_all_defect()
register_all_neudefect()
register_all_tcal()
